# coding=utf-8

import scrapy
from tutorial.items import TutorialItem

class TutorialSpider(scrapy.spiders.Spider):
    name = 'tutorial'  # 爬虫名称，要唯一，不同的Spider不能有相同的名称
    start_urls = ['http://www.example.com']  # 包含Spider在启动时进行爬取的URL列表，第一个被爬取的页面是列表中的其中一个，后续的URL则可从获取的数据中提取

    '''
    这是Spider的一个方法，被调用时，每个初始的URL完成下载后生成的Response对象会传递给这个方法。
    这个方法负责解析返回的Response数据、提取数据、生成进一步处理的URL的Request对象。
    '''
    def parse(self, response):
        filename = './tutorial.txt'
        with open(filename, 'wb') as f:
            f.write(response.url)  # 把URL写入文件
            f.write('\n')  # 写入换行
            f.write(response.body)  # 把响应的内容写入文件


class TutorialSpider2(scrapy.spiders.Spider):
    name = 'tutorial2'  # 爬虫名称，要唯一，不同的Spider不能有相同的名称
    start_urls = ['http://www.example.com']  # 包含Spider在启动时进行爬取的URL列表，第一个被爬取的页面是列表中的其中一个，后续的URL则可从获取的数据中提取

    '''
    这是Spider的一个方法，被调用时，每个初始的URL完成下载后生成的Response对象会传递给这个方法。
    这个方法负责解析返回的Response数据、提取数据、生成进一步处理的URL的Request对象。
    '''

    def parse(self, response):
        filename = './tutorial2.txt'
        f = open(filename, 'wb')  # 打开文件
        title = response.xpath('//div/h1/text()').extract_first()  # 获取h1里的文本
        f.write(title)  # h1文本写入文件
        f.write('\n')  # 写入换行
        content = response.xpath('//div/p')[0].xpath('text()').get()  # 获取第一个p里的文本
        f.write(content)  # 第一个p里的文本写入文件
        f.write('\n')  # 写入换行
        f.close()  # 关闭文件


class TutorialSpider3(scrapy.spiders.Spider):
    name = 'tutorial3'  # 爬虫名称，要唯一，不同的Spider不能有相同的名称
    start_urls = ['http://www.example.com']  # 包含Spider在启动时进行爬取的URL列表，第一个被爬取的页面是列表中的其中一个，后续的URL则可从获取的数据中提取

    '''
    这是Spider的一个方法，被调用时，每个初始的URL完成下载后生成的Response对象会传递给这个方法。
    这个方法负责解析返回的Response数据、提取数据、生成进一步处理的URL的Request对象。
    '''

    def parse(self, response):
        title = response.xpath('//div/h1/text()').extract_first()  # 获取h1里的文本
        content = response.xpath('//div/p')[0].xpath('text()').get()  # 获取第一个p里的文本
        item = TutorialItem()
        item['title'] = title
        item['content'] = content
        yield item