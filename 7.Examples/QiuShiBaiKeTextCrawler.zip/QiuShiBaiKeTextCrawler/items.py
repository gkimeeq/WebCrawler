# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy



class QiushibaiketextcrawlerItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    pass


class QiuShiBaiKeTextItem(scrapy.Item):
    title = scrapy.Field()  # 标题
    content = scrapy.Field()  # 内容
    funny_count = scrapy.Field()  # 认为好笑的数目
    comment_count = scrapy.Field()  # 评论数
    god_comment = scrapy.Field()  # 神评论
    god_comment_like_count = scrapy.Field()  # 神评论点赞数
