# coding=utf-8

import scrapy
from QiuShiBaiKeTextCrawler.items import QiuShiBaiKeTextItem


class QiuShiBaiKeTextSpider(scrapy.Spider):
    name = 'QiuShiBaiKeTextSpider'
    allowed_domains = ['qiushibaike.com']
    start_urls = ['https://www.qiushibaike.com/text/']

    def parse(self, response):
        selector = scrapy.Selector(response)
        div_list = selector.xpath('//div[@id="content-left"]/div')
        for div in div_list:
            title = div.xpath('div[@class="author clearfix"]/a/h2/text()').extract()  # 标题
            content = div.xpath('a/div[@class="content"]/span/text()').extract()  # 内容
            funny_count = div.xpath(
                'div[@class="stats"]/span[@class="stats-vote"]/i[@class="number"]/text()').extract()  # 认为好笑的数目
            comment_count = div.xpath(
                'div[@class="stats"]/span[@class="stats-comments"]/a/i[@class="number"]/text()').extract()  # 评论数
            god_comment_name = div.xpath(
                'a[@class="indexGodCmt"]/div[@class="cmtMain"]/span[@class="cmt-name"]/text()').extract()  # 需要测试是否存在
            god_comment_content = div.xpath(
                'a[@class="indexGodCmt"]/div[@class="cmtMain"]/div[@class="main-text"]/text()').extract()  # 需要测试是否存在
            god_comment = god_comment_name + god_comment_content
            god_comment_like_count = div.xpath(
                'a[@class="indexGodCmt"]/div[@class="cmtMain"]/div[@class="main-text"]/div[@class="likenum"]/text()').extract()  # 需要测试是否存在
            item = QiuShiBaiKeTextItem()
            item['title'] = title
            item['content'] = content
            item['funny_count'] = funny_count
            item['comment_count'] = comment_count
            item['god_comment'] = god_comment
            item['god_comment_like_count'] = god_comment_like_count
            yield item  # 生成的item由MySQLPipeline处理

        # 处理下一页
        lis = selector.xpath('//div[@id="content-left"]/ul[@class="pagination"]/li')
        href = lis[-1].xpath('a').xpath('@href').extract()[0]
        next_page_url = 'https://www.qiushibaike.com' + href
        if next_page_url:
            yield scrapy.Request(url=next_page_url, callback=self.parse)
