# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html

import pymysql

class QiushibaiketextcrawlerPipeline(object):
    def process_item(self, item, spider):
        return item


'''
CREATE SCHEMA `qiushibaike` DEFAULT CHARACTER SET utf8 ;

CREATE TABLE `qiushibaike`.`textitem` (
  `id` INT NOT NULL,
  `title` VARCHAR(45) NOT NULL,
  `content` VARCHAR(1024) NOT NULL,
  `funny_count` INT NULL,
  `comment_count` INT NULL,
  `god_comment` VARCHAR(45) NULL,
  `god_comment_like_count` INT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `id_UNIQUE` (`id` ASC) VISIBLE);
'''
class MySQLPipeline(object):
    def __init__(self, host, port, user, passwd, db):
        self.host = host
        self.port = port
        self.user = user
        self.passwd = passwd
        self.db = db

    @classmethod
    def from_crawler(cls, crawler):
        return cls(host=crawler.settings.get('MYSQL_HOST', '127.0.0.1'),
                   port=crawler.settings.get('MYSQL_PORT', 3306),
                   user=crawler.settings.get('MYSQL_USER', 'root'),
                   passwd=crawler.settings.get('MYSQL_PASSWD', 'root'),
                   db=crawler.settings.get('MYSQL_DB', 'qiushibaike'))

    def open_spider(self, spider):
        self.conn = pymysql.connect(host=self.host, port=self.port, user=self.user, passwd=self.passwd, db=self.db, charset='utf-8')
        self.conn.autocommit(True)
        self.cursor = self.conn.cursor()

    def close_spider(self, spider):
        self.conn.commit()
        self.cursor.close()
        self.conn.close()

    def process_item(self, item, spider):
        sql = 'insert into textitem (title, content, funny_count, comment_count, god_comment, god_comment_like_count) values (%s, %s, %s, %s, %s, %s)'
        textitem = (item['title'], item['content'], item['funny_count'], item['comment_count'], item['god_comment'], item['god_comment_like_count'])
        self.cursor.execute(sql, textitem)
        return item
